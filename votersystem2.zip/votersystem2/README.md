# votersystem2
This is the course project of seng3210
